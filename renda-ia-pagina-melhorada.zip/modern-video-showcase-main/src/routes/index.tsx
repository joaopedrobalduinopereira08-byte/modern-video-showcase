import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Check, Cpu, Workflow, ClipboardCheck, ShieldCheck, Zap, Sparkles } from "lucide-react";

const LINK = "https://go.hotmart.com/X108292328M?dp=1";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Renda IA Guide Easy | Comece a usar ferramentas de IA" },
      { name: "description", content: "Conheça o Renda IA Guide Easy: ferramentas de IA gratuitas, automação inteligente e um plano de ação para começar." },
      { property: "og:title", content: "Renda IA Guide Easy — Um caminho para começar com IA" },
      { property: "og:description", content: "Conheça o treinamento e veja como ferramentas de IA, automação e um plano de ação podem ajudar você a dar os primeiros passos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Cta({ children, big = false }: { children: React.ReactNode; big?: boolean }) {
  return (
    <a href={LINK} target="_blank" rel="noopener noreferrer"
      className={`group inline-flex items-center justify-center gap-3 rounded-full bg-primary px-7 py-4 font-display font-extrabold text-primary-foreground shadow-glow transition hover:scale-[1.02] hover:brightness-110 ${big ? "px-9 py-5 text-lg" : ""}`}>
      {children}
      <span className="grid size-8 place-items-center rounded-full bg-primary-foreground/15 transition group-hover:translate-x-1">
        <ArrowRight className="size-4" />
      </span>
    </a>
  );
}

const lessons = [
  { icon: Cpu, title: "Ferramentas de IA gratuitas", body: "Conheça recursos de inteligência artificial e entenda como começar a explorá-los." },
  { icon: Workflow, title: "Automação inteligente", body: "Veja como pensar em tarefas e processos que podem ser apoiados por ferramentas de IA." },
  { icon: ClipboardCheck, title: "Plano de ação", body: "Organize os próximos passos para sair da curiosidade e começar a praticar." },
];

const faqs = [
  ["O que é o Renda IA Guide Easy?", "É um treinamento apresentado como um caminho inicial para conhecer ferramentas de IA gratuitas, automação inteligente e um plano de ação."],
  ["Preciso saber usar inteligência artificial?", "O anúncio apresenta o treinamento para quem está buscando por onde começar. Consulte a página oficial para ver os requisitos e detalhes completos do conteúdo."],
  ["O que vou aprender?", "A apresentação do treinamento destaca ferramentas de IA gratuitas, automação inteligente e plano de ação. Consulte a oferta oficial para conferir a grade completa."],
  ["Como recebo o acesso?", "A compra e as informações de acesso são disponibilizadas pela Hotmart. Confira as condições na página oficial antes de finalizar."],
  ["Existe garantia?", "O anúncio informa garantia de 7 dias. Confira os termos e as condições aplicáveis na página oficial da Hotmart."],
];

function Index() {
  return (
    <main className="min-h-screen overflow-hidden bg-background">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="#" className="font-display text-xl font-black tracking-tight">RENDA <span className="text-gradient">IA</span></a>
          <a href="#conteudo" className="hidden text-sm text-muted-foreground transition hover:text-foreground sm:block">O que você vai aprender</a>
          <a href={LINK} target="_blank" rel="noopener noreferrer" className="rounded-full border border-primary/50 px-4 py-2 text-sm font-bold transition hover:bg-primary/15">Ver treinamento</a>
        </div>
      </header>

      <section className="bg-hero relative px-5 pb-20 pt-32 sm:pt-36">
        <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[1.15fr_.85fr]">
          <div className="fade-up">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-xs font-extrabold uppercase tracking-wider text-primary-glow">
              <Sparkles className="size-4" /> Renda IA Guide Easy
            </div>
            <h1 className="max-w-3xl text-4xl font-black leading-[1.08] sm:text-6xl">
              Quer começar com IA, mas não sabe <span className="text-gradient">por onde?</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground sm:text-xl">
              Conheça um treinamento que reúne <strong className="text-foreground">ferramentas de IA gratuitas, automação inteligente e um plano de ação</strong> para ajudar você a dar os primeiros passos com mais direção.
            </p>
            <div className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <Cta big>Quero conhecer o treinamento</Cta>
              <span className="text-xs text-muted-foreground">Veja os detalhes da oferta na Hotmart</span>
            </div>
            <div className="mt-7 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-2"><Check className="size-4 text-primary-glow" /> Conteúdo sobre IA</span>
              <span className="inline-flex items-center gap-2"><Check className="size-4 text-primary-glow" /> Plano de ação</span>
              <span className="inline-flex items-center gap-2"><Check className="size-4 text-primary-glow" /> Acesso pela Hotmart</span>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <div className="absolute -inset-5 rounded-[2rem] bg-primary/15 blur-3xl" />
            <div className="relative rounded-[2rem] border border-primary/25 bg-card/90 p-6 shadow-2xl sm:p-8">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-widest text-primary-glow">Dentro do treinamento</span>
                <Zap className="size-5 text-primary-glow" />
              </div>
              <h2 className="mt-5 font-display text-2xl font-black">Um começo mais organizado com IA</h2>
              <div className="mt-6 space-y-3">
                {lessons.map(({ icon: Icon, title, body }, i) => (
                  <div key={title} className="flex gap-4 rounded-xl border border-border bg-background/60 p-4">
                    <div className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary/15 text-primary-glow"><Icon className="size-5" /></div>
                    <div><p className="font-bold">{i + 1}. {title}</p><p className="mt-1 text-sm leading-relaxed text-muted-foreground">{body}</p></div>
                  </div>
                ))}
              </div>
              <p className="mt-5 text-xs text-muted-foreground">Confira a grade completa, os valores e as condições diretamente na oferta oficial.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-5 py-16">
        <div className="mx-auto max-w-4xl text-center">
          <p className="text-sm font-extrabold uppercase tracking-widest text-primary-glow">Você não precisa começar sabendo tudo</p>
          <h2 className="mt-4 text-3xl font-black leading-tight sm:text-5xl">O desafio não é só encontrar ferramentas. <span className="text-gradient">É saber por onde começar.</span></h2>
          <p className="mx-auto mt-5 max-w-2xl text-muted-foreground sm:text-lg">Com tantas ferramentas e possibilidades, é fácil ficar perdido. A proposta do Guide Easy é apresentar três pilares para orientar seu início: conhecer recursos, entender automações e organizar um plano de ação.</p>
        </div>
      </section>

      <section id="conteudo" className="px-5 py-16">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-sm font-extrabold uppercase tracking-widest text-primary-glow">O que você vai aprender</p>
            <h2 className="mt-3 text-3xl font-black sm:text-5xl">Três pilares para dar os primeiros passos</h2>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {lessons.map(({ icon: Icon, title, body }) => (
              <article key={title} className="rounded-2xl border border-border bg-card/60 p-7 transition hover:-translate-y-1 hover:shadow-glow">
                <div className="grid size-12 place-items-center rounded-xl bg-primary/15 text-primary-glow"><Icon className="size-6" /></div>
                <h3 className="mt-5 font-display text-xl font-extrabold">{title}</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{body}</p>
              </article>
            ))}
          </div>
          <div className="mt-10 text-center"><Cta>Quero ver a oferta completa</Cta></div>
        </div>
      </section>

      <section className="px-5 py-16">
        <div className="mx-auto grid max-w-5xl gap-8 rounded-3xl border border-primary/25 bg-card/60 p-7 sm:p-10 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <div className="flex items-center gap-2 text-primary-glow"><ShieldCheck className="size-5" /><span className="text-sm font-extrabold uppercase tracking-wider">Confira as condições</span></div>
            <h2 className="mt-4 text-3xl font-black sm:text-4xl">Conheça o treinamento e veja se ele faz sentido para você</h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">O anúncio apresenta acesso imediato e garantia de 7 dias. Consulte na Hotmart o preço atual, os itens incluídos e os termos completos antes de comprar.</p>
          </div>
          <Cta big>Ver oferta oficial</Cta>
        </div>
      </section>

      <section id="faq" className="px-5 py-16">
        <div className="mx-auto max-w-3xl">
          <p className="text-center text-sm font-extrabold uppercase tracking-widest text-primary-glow">Dúvidas frequentes</p>
          <h2 className="mt-3 text-center text-3xl font-black sm:text-4xl">Antes de começar</h2>
          <div className="mt-8 space-y-3">
            {faqs.map(([q, a]) => (
              <details key={q} className="group rounded-2xl border border-border bg-card/60 p-5">
                <summary className="cursor-pointer list-none font-display font-bold">{q}</summary>
                <p className="mt-3 leading-relaxed text-muted-foreground">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-hero px-5 py-20 text-center">
        <div className="mx-auto max-w-3xl">
          <p className="text-sm font-extrabold uppercase tracking-widest text-primary-glow">Renda IA Guide Easy</p>
          <h2 className="mt-4 text-3xl font-black sm:text-5xl">Comece entendendo as possibilidades da <span className="text-gradient">inteligência artificial</span></h2>
          <p className="mx-auto mt-5 max-w-2xl text-muted-foreground">Conheça o conteúdo, confira as condições e decida com tranquilidade.</p>
          <div className="mt-8"><Cta big>Conhecer o treinamento</Cta></div>
          <p className="mt-8 text-xs text-muted-foreground">O treinamento não garante renda ou resultados específicos. Os resultados dependem de diversos fatores, incluindo aplicação e dedicação individual.</p>
        </div>
      </section>

      <footer className="border-t border-border px-5 py-8 text-center text-xs text-muted-foreground">
        <p>RENDA IA · Guide Easy</p>
        <p className="mt-2">Consulte os detalhes e as condições oficiais da oferta na Hotmart.</p>
      </footer>

      <div className="fixed inset-x-4 bottom-4 z-50 sm:hidden">
        <a href={LINK} target="_blank" rel="noopener noreferrer" className="block rounded-full bg-primary py-4 text-center font-display font-extrabold text-primary-foreground shadow-glow">Conhecer o treinamento →</a>
      </div>
    </main>
  );
}
